export class User {
    id?: any;
    email?: string;
    password?: string;
}